#pragma once
#include <Arduino.h>
#include <ArduinoJson.h>

// Buat JSON string dari sensor
String buildSensorJSON();