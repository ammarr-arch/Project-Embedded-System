#pragma once

void initSerial(int baud);
