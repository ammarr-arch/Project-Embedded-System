#pragma once

void initSensorLDR(int pin);
void readSensorLDR();
int getLightLevel();