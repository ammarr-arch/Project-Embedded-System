#pragma once

// Tampilkan data ke Serial atau Dashboard
void showDashboard();