#pragma once

// Inisialisasi Web Server Dashboard
void initWebDashboard();

// Update data JSON di Web Dashboard
void handleWebDashboard();
